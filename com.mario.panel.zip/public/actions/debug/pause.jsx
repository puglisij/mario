/**
* Notify the Pipeline to pause asap
*/
debug.pause = function pause()
{
    alert("paused");
}