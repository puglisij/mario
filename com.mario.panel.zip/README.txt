Move these to README.md

Great post on modifying data in child components 
https://antenna.io/blog/2018/01/state-management-in-vue-js/

Its easiest to develop if you add a symbolic link to:
C:/Users/<user>/AppData/Roaming/Adobe/CEP/extensions  
and point it to the repo directory. 

