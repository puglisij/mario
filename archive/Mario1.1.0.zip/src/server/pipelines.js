/**
 * Manages JSX Pipeline Environment/Process, composed of JSX Actions 
 */
class Pipelines
{
    constructor()
    {

    }


}