<template>

</template>

<script>
export default {
    // TODO Rete.js editor
}
</script>

<style scoped>

</style>