action.saveDocument = function saveDocument() 
{
    activeDocument.save();
}