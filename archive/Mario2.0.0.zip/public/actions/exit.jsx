/**
* Exit the current pipeline stream
*/ 
action.exit = function exit()
{
    return "EXIT";
}