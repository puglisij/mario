/**
* Pause the current pipeline stream
*/ 
action.pause = function pause()
{
    return "PAUSE";
}