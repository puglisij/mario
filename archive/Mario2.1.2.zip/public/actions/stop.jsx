/**
* Exit the current pipeline stream
*/ 
action.stop = function stop()
{
    return "STOP";
}