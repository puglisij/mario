<template>

</template>

<script>
/* npm modules */
import Rete from "rete"; 
import ConnectionPlugin from "rete-connection-plugin";
import VueRenderPlugin from "rete-vue-render-plugin";

export default {
    // TODO Rete.js editor
    name: "pipeline-editor", 
    mounted() {
        const numSocket = new Rete.Socket('Number value');
        
    }
}
</script>

<style scoped>

</style>