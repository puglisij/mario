/**
* Core functionality to support pipeline engine
*/
